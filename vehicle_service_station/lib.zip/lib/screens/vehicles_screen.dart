import 'package:flutter/material.dart';
import '../models/vehicle.dart';

class VehiclesScreen extends StatefulWidget {
  const VehiclesScreen({super.key});

  @override
  State<VehiclesScreen> createState() => _VehiclesScreenState();
}

class _VehiclesScreenState extends State<VehiclesScreen> {
  final List<Vehicle> vehicles = [];
  final nameController = TextEditingController();
  final numberController = TextEditingController();
  VehicleType selectedType = VehicleType.car;
  String? numberError;

  void _addVehicle() {
    final number = numberController.text.trim();
    final name = nameController.text.trim();
    final validNumber = RegExp(r'^[a-zA-Z0-9]{4,}$');
    if (name.isEmpty || number.isEmpty) return;
    if (!validNumber.hasMatch(number)) {
      setState(() {
        numberError = "Enter a valid vehicle number (min 4 alphanumeric chars)";
      });
      return;
    }
    setState(() {
      vehicles.add(Vehicle(name: name, number: number, type: selectedType));
      nameController.clear();
      numberController.clear();
      numberError = null;
    });
  }

  void _removeVehicle(int index) {
    setState(() => vehicles.removeAt(index));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Manage Vehicles"),
        backgroundColor: Colors.blueAccent,
        elevation: 2,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.15),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "Add New Vehicle",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: nameController,
                            decoration: const InputDecoration(
                              labelText: "Vehicle Name",
                              border: OutlineInputBorder(),
                              prefixIcon: Icon(Icons.directions_car),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: TextField(
                            controller: numberController,
                            decoration: InputDecoration(
                              labelText: "Vehicle Number",
                              border: const OutlineInputBorder(),
                              prefixIcon: const Icon(Icons.confirmation_number),
                              errorText: numberError,
                            ),
                            onChanged: (_) {
                              if (numberError != null) {
                                setState(() => numberError = null);
                              }
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: DropdownButtonFormField<VehicleType>(
                            value: selectedType,
                            decoration: const InputDecoration(
                              labelText: "Type",
                              border: OutlineInputBorder(),
                            ),
                            items: VehicleType.values.map((type) {
                              return DropdownMenuItem(
                                value: type,
                                child: Text(type.name.toUpperCase()),
                              );
                            }).toList(),
                            onChanged: (value) =>
                                setState(() => selectedType = value!),
                          ),
                        ),
                        const SizedBox(width: 12),
                        ElevatedButton.icon(
                          onPressed: _addVehicle,
                          icon: const Icon(Icons.add),
                          label: const Text("Add Vehicle"),
                          style: ElevatedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 20,
                              vertical: 18,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 28),
              const Text(
                "Your Vehicles",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 12),
              vehicles.isEmpty
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.only(top: 40),
                        child: Text(
                          "No vehicles added yet.",
                          style: TextStyle(
                            color: Colors.grey[600],
                            fontSize: 16,
                          ),
                        ),
                      ),
                    )
                  : ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: vehicles.length,
                      itemBuilder: (context, index) {
                        final v = vehicles[index];
                        return Card(
                          margin: const EdgeInsets.symmetric(vertical: 8),
                          elevation: 3,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: ListTile(
                            leading: Icon(
                              v.type == VehicleType.car
                                  ? Icons.directions_car
                                  : v.type == VehicleType.bike
                                  ? Icons.motorcycle
                                  : Icons.local_shipping,
                              color: Colors.blueAccent,
                              size: 32,
                            ),
                            title: Text(
                              v.name,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            subtitle: Text(
                              "${v.number} • ${v.type.name.toUpperCase()}",
                            ),
                            trailing: IconButton(
                              icon: const Icon(
                                Icons.delete,
                                color: Colors.redAccent,
                              ),
                              onPressed: () => _removeVehicle(index),
                              tooltip: "Remove",
                            ),
                          ),
                        );
                      },
                    ),
            ],
          ),
        ),
      ),
    );
  }
}
