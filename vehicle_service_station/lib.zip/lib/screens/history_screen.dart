import 'package:flutter/material.dart';
import '../models/booking.dart';
import '../models/vehicle.dart';
import '../models/service_station.dart';

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Booking> bookings = [
      Booking(
        vehicle: Vehicle(name: "Car ", number: "AB123", type: VehicleType.car),
        station: ServiceStation(
          name: "QuickFix Garage",
          location: "Downtown",
          supportedTypes: [VehicleType.car, VehicleType.bike],
        ),
        date: DateTime.now().subtract(const Duration(days: 1)),
      ),
    ];

    String formatDate(DateTime date) {
      return "${date.day}/${date.month}/${date.year}  ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}";
    }

    // Get unique vehicles from bookings
    final uniqueVehicles = <String, Vehicle>{};
    for (final booking in bookings) {
      uniqueVehicles[booking.vehicle.number] = booking.vehicle;
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text("Booking History"),
        backgroundColor: Colors.blueAccent,
        elevation: 2,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: bookings.isEmpty
            ? Center(
                child: Text(
                  "No bookings yet.",
                  style: TextStyle(color: Colors.grey[600], fontSize: 18),
                ),
              )
            : ListView(
                children: [
                  if (uniqueVehicles.isNotEmpty) ...[
                    const Text(
                      "Vehicles that booked services:",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      height: 90,
                      child: ListView.separated(
                        scrollDirection: Axis.horizontal,
                        itemCount: uniqueVehicles.length,
                        separatorBuilder: (context, i) =>
                            const SizedBox(width: 16),
                        itemBuilder: (context, i) {
                          final v = uniqueVehicles.values.elementAt(i);
                          return Card(
                            elevation: 3,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 18,
                                vertical: 10,
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(
                                    v.type == VehicleType.car
                                        ? Icons.directions_car
                                        : v.type == VehicleType.bike
                                        ? Icons.motorcycle
                                        : Icons.local_shipping,
                                    color: Colors.blueAccent,
                                    size: 32,
                                  ),
                                  const SizedBox(width: 10),
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        v.name,
                                        style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      Text(
                                        v.number,
                                        style: const TextStyle(
                                          color: Colors.black54,
                                        ),
                                      ),
                                      Text(
                                        v.type.name.toUpperCase(),
                                        style: const TextStyle(
                                          fontSize: 12,
                                          color: Colors.grey,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 28),
                  ],
                  ...List.generate(bookings.length, (index) {
                    final b = bookings[index];
                    return Card(
                      elevation: 4,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(18),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Icon(
                              b.vehicle.type == VehicleType.car
                                  ? Icons.directions_car
                                  : b.vehicle.type == VehicleType.bike
                                  ? Icons.motorcycle
                                  : Icons.local_shipping,
                              color: Colors.blueAccent,
                              size: 36,
                            ),
                            const SizedBox(width: 18),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    b.vehicle.name,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 18,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    "Number: ${b.vehicle.number} • ${b.vehicle.type.name.toUpperCase()}",
                                    style: const TextStyle(
                                      color: Colors.black87,
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  Row(
                                    children: [
                                      const Icon(
                                        Icons.location_on,
                                        size: 18,
                                        color: Colors.grey,
                                      ),
                                      const SizedBox(width: 4),
                                      Text(
                                        b.station.name,
                                        style: const TextStyle(
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Text(
                                        "(${b.station.location})",
                                        style: const TextStyle(
                                          color: Colors.grey,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 8),
                                  Row(
                                    children: [
                                      const Icon(
                                        Icons.calendar_today,
                                        size: 18,
                                        color: Colors.grey,
                                      ),
                                      const SizedBox(width: 4),
                                      Text(
                                        formatDate(b.date),
                                        style: const TextStyle(
                                          color: Colors.black87,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }),
                ],
              ),
      ),
    );
  }
}
