import 'package:flutter/material.dart';
import '../models/vehicle.dart';
import '../models/service_station.dart';
import '../models/booking.dart';

class BookServiceScreen extends StatefulWidget {
  const BookServiceScreen({super.key});

  @override
  State<BookServiceScreen> createState() => _BookServiceScreenState();
}

class _BookServiceScreenState extends State<BookServiceScreen> {
  final List<Vehicle> vehicles = [
    Vehicle(name: "Car ", number: "AB123", type: VehicleType.car),
    Vehicle(name: "Bike ", number: "CD456", type: VehicleType.bike),
    Vehicle(name: "Truck ", number: "EF789", type: VehicleType.truck),
  ];

  final List<ServiceStation> stations = [
    ServiceStation(
      name: "QuickFix Garage",
      location: "Mangalore",
      supportedTypes: [VehicleType.car],
    ),
    ServiceStation(
      name: "BikeFix Garage",
      location: "Mangalore",
      supportedTypes: [VehicleType.bike],
    ),
    ServiceStation(
      name: "TruckPro Services",
      location: "Surathkal",
      supportedTypes: [VehicleType.truck],
    ),
  ];

  Vehicle? selectedVehicle;
  ServiceStation? selectedStation;
  DateTime selectedDate = DateTime.now();
  final List<Booking> bookings = [];

  void _bookService() {
    if (selectedVehicle != null && selectedStation != null) {
      setState(() {
        bookings.add(
          Booking(
            vehicle: selectedVehicle!,
            station: selectedStation!,
            date: selectedDate,
          ),
        );
      });
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("Service booked!")));
    }
  }

  @override
  Widget build(BuildContext context) {
    final filteredStations = selectedVehicle == null
        ? []
        : stations
              .where((s) => s.supportedTypes.contains(selectedVehicle!.type))
              .toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text("Book a Service"),
        backgroundColor: Colors.blueAccent,
        elevation: 2,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Center(
            child: Card(
              elevation: 5,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18),
              ),
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: const [
                        Icon(
                          Icons.build_circle,
                          color: Colors.blueAccent,
                          size: 32,
                        ),
                        SizedBox(width: 10),
                        Text(
                          "Book a Service",
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),
                    DropdownButtonFormField<Vehicle>(
                      decoration: const InputDecoration(
                        labelText: "Select Vehicle",
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.directions_car),
                      ),
                      value: selectedVehicle,
                      items: vehicles.map((v) {
                        return DropdownMenuItem(
                          value: v,
                          child: Text(
                            "${v.name} (${v.number}) - ${v.type.name.toUpperCase()}",
                          ),
                        );
                      }).toList(),
                      onChanged: (v) => setState(() {
                        selectedVehicle = v;
                        selectedStation = null;
                      }),
                    ),
                    const SizedBox(height: 18),
                    DropdownButtonFormField<ServiceStation>(
                      decoration: const InputDecoration(
                        labelText: "Select Station",
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.location_on),
                      ),
                      value: selectedStation,
                      items: filteredStations.map((s) {
                        return DropdownMenuItem<ServiceStation>(
                          value: s,
                          child: Text("${s.name} - ${s.location}"),
                        );
                      }).toList(),
                      onChanged: (s) => setState(() => selectedStation = s),
                    ),
                    const SizedBox(height: 18),
                    InkWell(
                      borderRadius: BorderRadius.circular(8),
                      onTap: () async {
                        final picked = await showDatePicker(
                          context: context,
                          initialDate: selectedDate,
                          firstDate: DateTime.now(),
                          lastDate: DateTime.now().add(
                            const Duration(days: 365),
                          ),
                        );
                        if (picked != null) {
                          setState(() => selectedDate = picked);
                        }
                      },
                      child: InputDecorator(
                        decoration: const InputDecoration(
                          labelText: "Select Date",
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(Icons.calendar_today),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          child: Text(
                            "${selectedDate.day}/${selectedDate.month}/${selectedDate.year}",
                            style: const TextStyle(fontSize: 16),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 28),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: _bookService,
                        icon: const Icon(Icons.check_circle_outline),
                        label: const Text(
                          "Book Service",
                          style: TextStyle(fontSize: 18),
                        ),
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          backgroundColor: Colors.blueAccent,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
