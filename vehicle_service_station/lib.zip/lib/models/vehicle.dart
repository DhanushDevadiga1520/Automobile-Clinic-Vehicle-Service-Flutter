enum VehicleType { car, bike, truck }

class Vehicle {
  String name;
  String number;
  VehicleType type;

  Vehicle({required this.name, required this.number, required this.type});
}