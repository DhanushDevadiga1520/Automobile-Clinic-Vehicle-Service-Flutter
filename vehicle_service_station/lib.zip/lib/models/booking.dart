import 'vehicle.dart';
import 'service_station.dart';

class Booking {
  Vehicle vehicle;
  ServiceStation station;
  DateTime date;

  Booking({required this.vehicle, required this.station, required this.date});
}