import 'vehicle.dart';

class ServiceStation {
  String name;
  String location;
  List<VehicleType> supportedTypes;

  ServiceStation({
    required this.name,
    required this.location,
    required this.supportedTypes,
  });
}